import random
import string

def main():
    xor_encoded_flag = '3a380f15095f112e000d2b08362f0d1a4421051a2f1e305d18023c3b062c1c043b5e0c1c080d1c04'
    xor_bytes = bytes.fromhex(xor_encoded_flag)
    decoded = xor_bytes.decode('utf-8')
    while True:
        xored = ""
        res = ''.join(['npBn', ''.join(random.choices(string.ascii_letters + string.digits))] )
        key = str(res)
        for i in range(0,len(decoded)):
            xored += chr(ord(decoded[i]) ^ ord(key[i%len(key)]))
        if xored.startswith("THM{") and xored.endswith("}"):
            print("Possible Decrypted flag:", xored, "with key:", key)

main()